CS4495/6476
Project2: Local Feature Matching

Name: Liang Tang
GT ID: 902941560

Hi! Here is my solution to the project2. All the Matlab code are in the code file. 

I raised a question for implementing local feature descriptor. Since I used 4 layers nested 'for' loop in my function, it is very slow in Matlab. I want to know a better data structure or even some cheating approach to implement the descriptor.

Thank you!