All the result and project report are in the html file.
Matlab code is in the code folder.

One question:
My bag of SIFT + K Nearest Neighbor runs pretty fast, but the bag of SIFT and linear SVM is very slow. Is there any way to improve the performance of it in terms of running speed?

Thanks!